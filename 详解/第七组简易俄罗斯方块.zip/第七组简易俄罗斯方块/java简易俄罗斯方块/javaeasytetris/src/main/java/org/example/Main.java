package org.example;

/**
 * 游戏主入口类
 * <p>
 * 负责启动整个俄罗斯方块游戏。
 * 使用 {@code SwingUtilities.invokeLater} 确保UI操作在事件分发线程（EDT）中执行，
 * 这是Swing编程的最佳实践，可以避免线程安全问题。
 * </p>
 */
public class Main {
    /**
     * 程序主方法
     * @param args 命令行参数（未使用）
     */
    public static void main(String[] args) {
        // 确保Swing组件的创建和更新在事件分发线程中进行
        javax.swing.SwingUtilities.invokeLater(() -> {
            new TetrisGame();
        });
    }
}