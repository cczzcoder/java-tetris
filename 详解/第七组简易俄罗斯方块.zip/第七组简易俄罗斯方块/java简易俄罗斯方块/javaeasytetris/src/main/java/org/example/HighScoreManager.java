package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 排行榜管理器。
 * <p>
 * 负责从文本文件 ({@code tetris_leaderboard.txt}) 中加载和保存排行榜数据。
 * 它管理一个 {@link HighScoreEntry} 列表，并提供添加新纪录、获取排行榜、
 * 以及判断分数是否足够高等功能。
 * </p>
 */
public class HighScoreManager {
    /** 排行榜数据文件名 */
    private static final String FILE_NAME = "tetris_leaderboard.txt";
    /** 排行榜上最多记录的条目数 */
    private static final int MAX_SCORES = 10;
    /** 存储排行榜条目的列表 */
    private List<HighScoreEntry> scores;

    /**
     * 构造函数，初始化并加载排行榜数据。
     */
    public HighScoreManager() {
        scores = new ArrayList<>();
        load();
    }

    /**
     * 获取当前排行榜的只读列表。
     * @return 一个不可修改的排行榜列表
     */
    public List<HighScoreEntry> getHighScores() {
        return Collections.unmodifiableList(scores);
    }

    /**
     * 添加一个新的分数记录到排行榜。
     * <p>
     * 如果列表已满且新分数高于最低分，则替换最低分。
     * 添加后会自动排序并保存到文件。
     * </p>
     * @param name 玩家姓名
     * @param score 玩家分数
     */
    public void addScore(String name, int score) {
        scores.add(new HighScoreEntry(name, score));
        Collections.sort(scores);
        // 如果超出最大数量，则移除末尾的（即分数最低的）
        if (scores.size() > MAX_SCORES) {
            scores = scores.subList(0, MAX_SCORES);
        }
        save();
    }

    /**
     * 判断一个分数是否足够高，可以进入排行榜。
     * @param score 要判断的分数
     * @return 如果排行榜未满，或分数高于榜上最低分，则返回 true。
     */
    public boolean isHighScore(int score) {
        if (scores.size() < MAX_SCORES) {
            return true;
        }
        // 因为列表是降序的，所以最后一个是最低分
        return score > scores.get(scores.size() - 1).getScore();
    }

    /**
     * 从 {@code .txt} 文件加载排行榜数据。
     * <p>
     * 会自动处理文件不存在或格式错误的情况。
     * </p>
     */
    private void load() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 解析格式: "姓名： name | 分数： score"
                String[] parts = line.split(" \\| ");
                if (parts.length == 2) {
                    try {
                        String namePart = parts[0];
                        String scorePart = parts[1];
                        if (namePart.startsWith("姓名： ") && scorePart.startsWith("分数： ")) {
                            String name = namePart.substring("姓名： ".length()).trim();
                            int score = Integer.parseInt(scorePart.substring("分数： ".length()).trim());
                            scores.add(new HighScoreEntry(name, score));
                        }
                    } catch (Exception ignored) {
                        // 忽略格式错误的行
                    }
                }
            }
            Collections.sort(scores);
        } catch (IOException e) {
            // 文件读取失败，忽略
        }
    }

    /**
     * 将当前的排行榜数据保存到 {@code .txt} 文件。
     */
    private void save() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (HighScoreEntry entry : scores) {
                writer.write(entry.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            // 文件写入失败，忽略
        }
    }
} 