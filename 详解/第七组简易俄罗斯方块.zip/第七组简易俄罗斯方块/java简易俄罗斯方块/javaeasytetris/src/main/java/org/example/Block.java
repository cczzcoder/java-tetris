package org.example;

import java.io.Serializable;
import java.util.Random;

/**
 * 代表一个俄罗斯方块。
 * <p>
 * 包含了方块的形状 (一个二维数组)、颜色索引，以及旋转逻辑。
 * 这个类是可序列化的，以便于保存游戏状态。
 * </p>
 */
public class Block implements Serializable {
    /** 方块的形状，用二维数组表示，非0部分为方块实体 */
    public int[][] shape;
    /** 方块的颜色索引，对应于 TetrisPanel 中的 COLORS 数组 */
    public int colorIndex;

    /** 所有可能的方块形状定义 */
    private static final int[][][] SHAPES = {
            // I
            {{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},
            // J
            {{2,0,0},{2,2,2},{0,0,0}},
            // L
            {{0,0,3},{3,3,3},{0,0,0}},
            // O
            {{4,4},{4,4}},
            // S
            {{0,5,5},{5,5,0},{0,0,0}},
            // T
            {{0,6,0},{6,6,6},{0,0,0}},
            // Z
            {{7,7,0},{0,7,7},{0,0,0}}
    };
    /** 与 SHAPES 对应的颜色索引 */
    private static final int[] COLORS = {1,2,3,4,5,6,7};

    /**
     * 构造函数
     * @param shape 方块的形状
     * @param colorIndex 方块的颜色索引
     */
    public Block(int[][] shape, int colorIndex) {
        this.shape = new int[shape.length][shape[0].length];
        for (int i = 0; i < shape.length; i++)
            System.arraycopy(shape[i], 0, this.shape[i], 0, shape[0].length);
        this.colorIndex = colorIndex;
    }

    /**
     * 静态工厂方法，随机生成一个方块。
     * @return 一个随机形状和颜色的 Block 对象
     */
    public static Block randomBlock() {
        Random rand = new Random();
        int idx = rand.nextInt(SHAPES.length);
        int[][] s = SHAPES[idx];
        int color = COLORS[idx];
        return new Block(s, color);
    }

    /**
     * 将方块顺时针旋转90度。
     * @return 旋转后的新形状数组
     */
    public int[][] rotate() {
        int n = shape.length, m = shape[0].length;
        int[][] rotated = new int[m][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                rotated[j][n - 1 - i] = shape[i][j];
        return rotated;
    }
}