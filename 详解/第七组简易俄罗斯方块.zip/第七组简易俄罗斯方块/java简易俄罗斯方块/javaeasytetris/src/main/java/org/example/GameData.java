package org.example;

import java.io.Serializable;

/**
 * 用于封装游戏状态的数据类。
 * <p>
 * 这个类的对象可以被序列化，用于实现游戏的保存和加载功能。
 * 它包含了恢复一局游戏所需的所有关键信息。
 * </p>
 */
public class GameData implements Serializable {
    /** 游戏棋盘的布局 */
    public int[][] board;
    /** 当前正在下落的方块 */
    public Block currentBlock;
    /** 当前方块的行、列坐标 */
    public int curRow, curCol;
    /** 当前分数 */
    public int score;
    /** 游戏是否在运行（用于区分游戏结束和未开始） */
    public boolean running;
    /** 游戏是否已结束 */
    public boolean gameOver;

    /**
     * 构造函数。
     * @param board 游戏棋盘
     * @param currentBlock 当前方块
     * @param curRow 当前方块的行
     * @param curCol 当前方块的列
     * @param score 分数
     * @param running 游戏是否运行中
     * @param gameOver 游戏是否已结束
     */
    public GameData(int[][] board, Block currentBlock, int curRow, int curCol, int score, boolean running, boolean gameOver) {
        this.board = new int[board.length][board[0].length];
        for (int i = 0; i < board.length; i++)
            System.arraycopy(board[i], 0, this.board[i], 0, board[0].length);
        this.currentBlock = currentBlock;
        this.curRow = curRow;
        this.curCol = curCol;
        this.score = score;
        this.running = running;
        this.gameOver = gameOver;
    }
}