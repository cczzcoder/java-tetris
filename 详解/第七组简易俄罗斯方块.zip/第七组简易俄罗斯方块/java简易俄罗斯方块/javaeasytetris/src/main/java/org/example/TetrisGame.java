package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;

/**
 * 游戏主窗口类 (JFrame)
 * <p>
 * 负责管理整个游戏的UI布局，包括游戏主面板、信息面板（下一个方块、排行榜）、
 * 状态栏、以及菜单栏。同时，它也处理游戏的核心交互逻辑，如暂停、保存/加载、
 * 游戏结束处理等。
 * </p>
 */
public class TetrisGame extends JFrame {
    /** 游戏主面板，进行俄罗斯方块游戏的地方 */
    private TetrisPanel tetrisPanel;
    /** 下一个方块的预览面板 */
    private NextBlockPanel nextBlockPanel;
    /** 显示排行榜的文本区域 */
    private JTextArea leaderboardArea;
    /** 游戏状态标签，如"游戏进行中"、"已暂停"等 */
    private JLabel statusLabel;
    /** 排行榜管理器 */
    private HighScoreManager highScoreManager;
    /** 游戏是否暂停的标志 */
    private boolean paused = false;

    /**
     * 构造函数，初始化整个游戏窗口和所有UI组件。
     */
    public TetrisGame() {
        setTitle("简易俄罗斯方块");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 初始化右侧信息面板
        setupRightPanel();

        // 初始化状态栏
        statusLabel = new JLabel("欢迎来到俄罗斯方块！", SwingConstants.CENTER);
        statusLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        add(statusLabel, BorderLayout.SOUTH);

        // 初始化排行榜管理器和游戏主面板
        highScoreManager = new HighScoreManager();
        updateLeaderboardDisplay();

        tetrisPanel = new TetrisPanel(this);
        add(tetrisPanel, BorderLayout.CENTER);

        // 初始化菜单栏
        setupMenuBar();

        // 显示窗口
        setVisible(true);
        // tetrisPanel.startNewGame(); // 不再自动开始游戏
    }

    /**
     * 初始化右侧面板，包含下一个方块预览和排行榜。
     */
    private void setupRightPanel() {
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setPreferredSize(new Dimension(160, 600));
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createTitledBorder("信息"));

        rightPanel.add(Box.createVerticalStrut(20));
        rightPanel.add(new JLabel("下一个方块：", SwingConstants.CENTER));
        nextBlockPanel = new NextBlockPanel();
        rightPanel.add(nextBlockPanel);

        rightPanel.add(Box.createVerticalStrut(20));
        rightPanel.add(new JLabel("排行榜：", SwingConstants.CENTER));
        leaderboardArea = new JTextArea();
        leaderboardArea.setEditable(false);
        leaderboardArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(leaderboardArea);
        rightPanel.add(scrollPane);

        add(rightPanel, BorderLayout.EAST);
    }

    /**
     * 初始化菜单栏。
     */
    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu gameMenu = new JMenu("游戏");
        JMenuItem newGameItem = new JMenuItem("新游戏");
        JMenuItem saveItem = new JMenuItem("保存进度");
        JMenuItem loadItem = new JMenuItem("加载进度");
        JMenuItem pauseItem = new JMenuItem("暂停/继续 (P)");
        JMenuItem exitItem = new JMenuItem("退出");
        JMenu helpMenu = new JMenu("帮助");
        JMenuItem leaderboardItem = new JMenuItem("完整排行榜");
        JMenuItem aboutItem = new JMenuItem("关于");

        newGameItem.addActionListener(e -> tetrisPanel.startNewGame());
        saveItem.addActionListener(e -> saveGame());
        loadItem.addActionListener(e -> loadGame());
        pauseItem.addActionListener(e -> togglePause());
        exitItem.addActionListener(e -> System.exit(0));
        leaderboardItem.addActionListener(e -> showLeaderboard());
        aboutItem.addActionListener(e -> showAbout());

        gameMenu.add(newGameItem);
        gameMenu.add(saveItem);
        gameMenu.add(loadItem);
        gameMenu.add(pauseItem);
        gameMenu.add(exitItem);
        menuBar.add(gameMenu);
        helpMenu.add(leaderboardItem);
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
    }

    /**
     * 更新状态栏显示的信息。
     * @param msg 要显示的消息
     */
    public void showStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }

    /**
     * 更新右侧面板的排行榜显示。
     */
    private void updateLeaderboardDisplay() {
        if (leaderboardArea == null || highScoreManager == null) return;
        StringBuilder sb = new StringBuilder();
        List<HighScoreEntry> scores = highScoreManager.getHighScores();
        for (int i = 0; i < scores.size(); i++) {
            HighScoreEntry entry = scores.get(i);
            sb.append(String.format("%2d. %-8s %-5d\n", i + 1, entry.getName(), entry.getScore()));
        }
        leaderboardArea.setText(sb.toString());
    }

    /**
     * 设置下一个方块的预览。
     * @param block 要预览的方块
     */
    public void setNextBlock(Block block) {
        if (nextBlockPanel != null) nextBlockPanel.setNextBlock(block);
    }

    /**
     * 保存当前游戏进度到文件。
     */
    public void saveGame() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("tetris_save.dat"))) {
            out.writeObject(tetrisPanel.getGameData());
            showStatus("游戏已保存");
        } catch (IOException e) {
            showStatus("保存失败: " + e.getMessage());
        }
    }

    /**
     * 从文件加载游戏进度。
     */
    public void loadGame() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("tetris_save.dat"))) {
            GameData data = (GameData) in.readObject();
            tetrisPanel.loadGameData(data);
            showStatus("游戏已加载");
        } catch (Exception e) {
            showStatus("加载失败: " + e.getMessage());
        }
    }

    /**
     * 处理游戏结束的逻辑。
     * <p>
     * 弹出一个统一的对话框，显示最终分数，并在分数足够高时提供姓名输入框。
     * 玩家可以选择重新游戏或退出。
     * </p>
     * @param win 是否胜利
     * @param score 最终得分
     */
    public void showGameOver(boolean win, int score) {
        // 1. 设置状态栏信息
        if (win) {
            showStatus("恭喜你，胜利了！");
        } else {
            showStatus("游戏失败！");
        }

        // 2. 创建自定义对话框面板
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.add(new JLabel("游戏结束！最终分数: " + score), BorderLayout.NORTH);

        JTextField nameField = null;
        boolean isHighScore = highScoreManager.isHighScore(score);

        if (isHighScore) {
            JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            namePanel.add(new JLabel("恭喜上榜！请输入你的大名:"));
            nameField = new JTextField(10);
            namePanel.add(nameField);
            panel.add(namePanel, BorderLayout.CENTER);
        }

        // 3. 定义对话框选项
        String[] options = {"重新游戏", "退出游戏"};
        int choice = JOptionPane.showOptionDialog(
                this,
                panel,
                "游戏结束",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
        );

        // 4. 处理结果
        if (isHighScore && nameField != null) {
            String name = nameField.getText();
            if (name != null && !name.trim().isEmpty()) {
                highScoreManager.addScore(name.trim(), score);
                updateLeaderboardDisplay();
            }
        }

        if (choice == 0) { // 选择了 "重新游戏"
            tetrisPanel.startNewGame();
        } else { // 选择了 "退出游戏" 或关闭了对话框
            dispose();
        }
    }

    /**
     * 切换游戏的暂停/继续状态。
     */
    public void togglePause() {
        paused = !paused;
        tetrisPanel.setPaused(paused);
        showStatus(paused ? "已暂停，点击菜单或按P恢复" : "游戏进行中");
    }

    /**
     * 显示完整的排行榜弹窗。
     */
    private void showLeaderboard() {
        JTextArea fullLeaderboard = new JTextArea(12, 30);
        fullLeaderboard.setEditable(false);
        fullLeaderboard.setFont(new Font("Monospaced", Font.PLAIN, 14));
        StringBuilder sb = new StringBuilder("--- 排行榜 ---\n\n");
        List<HighScoreEntry> scores = highScoreManager.getHighScores();
        for (int i = 0; i < scores.size(); i++) {
            HighScoreEntry entry = scores.get(i);
            sb.append(String.format("%2d. %-10s %d\n", i + 1, entry.getName(), entry.getScore()));
        }
        fullLeaderboard.setText(sb.toString());
        JOptionPane.showMessageDialog(this, new JScrollPane(fullLeaderboard), "完整排行榜", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * 显示"关于"对话框。
     */
    private void showAbout() {
        JOptionPane.showMessageDialog(this,
                "简易俄罗斯方块\n\n操作说明：\n← → 左右移动\n↑ 旋转\n↓ 快速下落\n空格 直接落到底\n P  暂停/继续\n\n作者：AI助理\n2024年",
                "关于", JOptionPane.INFORMATION_MESSAGE);
    }
}