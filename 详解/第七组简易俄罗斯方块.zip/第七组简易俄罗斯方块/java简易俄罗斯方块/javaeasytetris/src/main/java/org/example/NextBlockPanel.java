package org.example;

import javax.swing.*;
import java.awt.*;

/**
 * 用于显示下一个将要出现的方块的预览面板 (JPanel)。
 */
public class NextBlockPanel extends JPanel {
    /** 下一个要显示的方块 */
    private Block nextBlock;
    /** 预览区域内，每个小格子的尺寸 */
    private static final int BLOCK_SIZE = 20;
    /** 颜色数组，与 TetrisPanel 保持一致 */
    private static final Color[] COLORS = {
            Color.BLACK, Color.CYAN, Color.BLUE, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.MAGENTA, Color.RED
    };

    /**
     * 构造函数，设置面板的基本属性。
     */
    public NextBlockPanel() {
        setPreferredSize(new Dimension(6 * BLOCK_SIZE, 6 * BLOCK_SIZE));
        setBackground(Color.WHITE);
    }

    /**
     * 设置要预览的下一个方块。
     * @param block 要显示的 Block 对象
     */
    public void setNextBlock(Block block) {
        this.nextBlock = block;
        repaint(); // 更新显示
    }

    /**
     * 绘制预览方块。
     * <p>
     * 方块会被绘制在面板的中央。
     * </p>
     * @param g 绘图上下文
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (nextBlock == null) return;

        // 计算偏移量，使方块居中
        int[][] shape = nextBlock.shape;
        int colorIdx = nextBlock.colorIndex;
        int offsetX = (getWidth() - shape[0].length * BLOCK_SIZE) / 2;
        int offsetY = (getHeight() - shape.length * BLOCK_SIZE) / 2;

        // 绘制方块
        g.setColor(COLORS[colorIdx]);
        for (int r = 0; r < shape.length; r++) {
            for (int c = 0; c < shape[0].length; c++) {
                if (shape[r][c] != 0) {
                    g.fill3DRect(offsetX + c * BLOCK_SIZE, offsetY + r * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE, true);
                }
            }
        }

        // 绘制边框
        g.setColor(Color.GRAY);
        g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
    }
} 