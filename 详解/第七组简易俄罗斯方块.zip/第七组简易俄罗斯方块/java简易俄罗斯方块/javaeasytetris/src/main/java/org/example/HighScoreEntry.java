package org.example;

/**
 * 排行榜条目，用于记录玩家姓名和分数。
 * <p>
 * 实现 {@link Comparable} 接口，以便于按分数从高到低进行排序。
 * </p>
 */
public class HighScoreEntry implements Comparable<HighScoreEntry> {
    private final String name;
    private final int score;

    /**
     * 构造函数。
     * @param name 玩家姓名
     * @param score 玩家分数
     */
    public HighScoreEntry(String name, int score) {
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    /**
     * 比较两个排行榜条目，用于排序。
     * @param other 另一个要比较的条目
     * @return 负数、零或正数，表示此对象小于、等于或大于指定对象。
     */
    @Override
    public int compareTo(HighScoreEntry other) {
        return Integer.compare(other.score, this.score); // 降序排列
    }

    /**
     * 将条目转换为字符串，用于文件存储。
     * @return 格式化的字符串，如 "姓名： Alice | 分数： 1200"
     */
    @Override
    public String toString() {
        return "姓名： " + name + " | 分数： " + score; // 用于文件存储
    }
} 