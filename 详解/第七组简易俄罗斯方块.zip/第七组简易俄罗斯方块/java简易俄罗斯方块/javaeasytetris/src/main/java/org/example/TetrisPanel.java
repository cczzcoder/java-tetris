package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.Random;

/**
 * 俄罗斯方块主游戏面板 (JPanel)
 * <p>
 * 这是游戏的核心，负责处理所有与游戏玩法直接相关的逻辑：
 * <ul>
 *     <li>绘制游戏棋盘、当前方块和已固定的方块。</li>
 *     <li>处理方块的下落、移动、旋转。</li>
 *     <li>响应玩家的键盘输入。</li>
 *     <li>管理游戏状态（开始、暂停、结束）。</li>
 *     <li>计算分数、消除行、并根据分数提升游戏速度。</li>
 *     <li>与主窗口 (TetrisGame) 交互，更新状态和预览。</li>
 * </ul>
 * </p>
 */
public class TetrisPanel extends JPanel implements ActionListener, KeyListener {
    private static final int ROWS = 20;
    private static final int COLS = 10;
    private static final int BLOCK_SIZE = 28;
    private static final Color[] COLORS = {
            Color.BLACK, Color.CYAN, Color.BLUE, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.MAGENTA, Color.RED
    };
    /** 游戏棋盘，用二维数组表示，0表示空，非0表示方块颜色索引 */
    private int[][] board = new int[ROWS][COLS];
    /** 当前正在下落的方块 */
    private Block currentBlock;
    /** 下一个将要出现的方块 */
    private Block nextBlock;
    /** 当前方块的行、列坐标 */
    private int curRow, curCol;
    /** Swing计时器，用于驱动方块定时下落 */
    private javax.swing.Timer timer;
    /** 游戏是否正在运行 */
    private boolean running = false;
    /** 游戏是否已暂停 */
    private boolean paused = false;
    /** 对父窗口(TetrisGame)的引用，用于通信 */
    private TetrisGame parent;
    /** 当前分数 */
    private int score = 0;
    /** 游戏是否已结束 */
    private boolean gameOver = false;
    /** 当前游戏速度（方块下落的间隔，单位：毫秒） */
    private int speed = 400;
    /** 用于倒计时的计时器 */
    private javax.swing.Timer countdownTimer;
    /** 倒计时当前的秒数 */
    private int countdownValue;

    /**
     * 构造函数
     * @param parent 对父窗口(TetrisGame)的引用
     */
    public TetrisPanel(TetrisGame parent) {
        this.parent = parent;
        setPreferredSize(new Dimension(COLS * BLOCK_SIZE, ROWS * BLOCK_SIZE));
        setBackground(Color.WHITE);
        setFocusable(true);
        addKeyListener(this);
    }

    /**
     * 开始一局新游戏。
     * <p>
     * 重置所有游戏状态：棋盘、分数、速度等，并生成第一个方块。
     * </p>
     */
    public void startNewGame() {
        for (int[] row : board) Arrays.fill(row, 0);
        score = 0;
        gameOver = false;
        speed = 400;
        running = false; // 游戏在倒计时结束前不算运行
        paused = false;

        // 停止可能正在运行的计时器
        if (timer != null) timer.stop();
        if (countdownTimer != null) countdownTimer.stop();

        nextBlock = Block.randomBlock();
        spawnBlock(); // 预先生成第一个方块，但它不会下落

        parent.setNextBlock(nextBlock);
        repaint();

        // 开始倒计时
        countdownValue = 5;
        parent.showStatus("游戏将在 " + countdownValue + " 秒后开始...");
        countdownTimer = new javax.swing.Timer(1000, this);
        countdownTimer.start();
    }

    /**
     * 生成一个新的方块。
     * <p>
     * 将预先生成的下一个方块 (nextBlock) 设为当前方块，并生成新的下一个方块。
     * 如果新生成的方块无法放置在顶部（即触顶），则游戏结束。
     * </p>
     */
    private void spawnBlock() {
        currentBlock = nextBlock;
        nextBlock = Block.randomBlock();
        parent.setNextBlock(nextBlock);
        curRow = 0;
        curCol = COLS / 2 - 2;
        if (!canMove(curRow, curCol, currentBlock.shape)) {
            running = false;
            timer.stop();
            gameOver = true;
            parent.showGameOver(false, score);
        }
    }

    /**
     * 检查指定的方块形状是否可以移动到目标位置。
     * @param row 目标行
     * @param col 目标列
     * @param shape 方块的形状数组
     * @return 如果可以移动，返回 true；否则返回 false。
     */
    private boolean canMove(int row, int col, int[][] shape) {
        for (int r = 0; r < shape.length; r++) {
            for (int c = 0; c < shape[0].length; c++) {
                if (shape[r][c] != 0) {
                    int nr = row + r, nc = col + c;
                    if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return false;
                    if (board[nr][nc] != 0) return false;
                }
            }
        }
        return true;
    }

    /**
     * 将当前方块的形状和颜色合并（固定）到游戏棋盘上。
     */
    private void mergeBlock() {
        for (int r = 0; r < currentBlock.shape.length; r++) {
            for (int c = 0; c < currentBlock.shape[0].length; c++) {
                if (currentBlock.shape[r][c] != 0) {
                    board[curRow + r][curCol + c] = currentBlock.colorIndex;
                }
            }
        }
    }

    /**
     * 检查并消除所有已满的行。
     * <p>
     * 消除行后，会增加分数，并根据当前分数调整游戏速度。
     * 如果分数达到胜利条件，则结束游戏。
     * </p>
     */
    private void clearLines() {
        int lines = 0;
        for (int r = ROWS - 1; r >= 0; r--) {
            boolean full = true;
            for (int c = 0; c < COLS; c++) {
                if (board[r][c] == 0) {
                    full = false;
                    break;
                }
            }
            if (full) {
                lines++;
                for (int rr = r; rr > 0; rr--) {
                    board[rr] = Arrays.copyOf(board[rr - 1], COLS);
                }
                board[0] = new int[COLS];
                r++;
            }
        }
        if (lines > 0) {
            // 根据消除的行数来计分
            switch (lines) {
                case 1: score += 100; break;
                case 2: score += 300; break;
                case 3: score += 600; break;
                case 4: score += 1000; break;
            }

            // 每消除一行加快速度
            int newSpeed = Math.max(100, 400 - score / 200 * 40);
            if (newSpeed != speed) {
                speed = newSpeed;
                timer.setDelay(speed);
            }
            if (score >= 10000) {
                running = false;
                timer.stop();
                parent.showGameOver(true, score);
            }
        }
    }

    /**
     * Swing Timer的回调方法，每次方块需要下落一格时调用。
     * @param e 事件对象
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // 判断事件来源
        if (e.getSource() == countdownTimer) {
            handleCountdown();
        } else if (e.getSource() == timer) {
            handleGameTick();
        }
    }

    /**
     * 处理倒计时逻辑。
     */
    private void handleCountdown() {
        countdownValue--;
        if (countdownValue > 0) {
            parent.showStatus("游戏将在 " + countdownValue + " 秒后开始...");
        } else {
            countdownTimer.stop();
            running = true; // 正式开始游戏
            parent.showStatus("游戏进行中");
            // 启动游戏主计时器
            timer = new javax.swing.Timer(speed, this);
            timer.start();
        }
        repaint();
    }

    /**
     * 处理游戏主循环的逻辑（方块下落）。
     */
    private void handleGameTick() {
        if (!running || paused) return;
        if (canMove(curRow + 1, curCol, currentBlock.shape)) {
            curRow++;
        } else {
            mergeBlock();
            clearLines();
            spawnBlock();
        }
        repaint();
    }

    /**
     * 绘制游戏面板的所有内容。
     * @param g 绘图上下文
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // 如果游戏未开始，则显示欢迎界面
        if (!running && !gameOver) {
            drawWelcomeScreen(g);
            return;
        }

        // 绘制已落下方块
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (board[r][c] != 0) {
                    g.setColor(COLORS[board[r][c]]);
                    g.fill3DRect(c * BLOCK_SIZE, r * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE, true);
                }
            }
        }
        // 绘制当前方块
        if (currentBlock != null) {
            g.setColor(COLORS[currentBlock.colorIndex]);
            for (int r = 0; r < currentBlock.shape.length; r++) {
                for (int c = 0; c < currentBlock.shape[0].length; c++) {
                    if (currentBlock.shape[r][c] != 0) {
                        int x = (curCol + c) * BLOCK_SIZE;
                        int y = (curRow + r) * BLOCK_SIZE;
                        g.fill3DRect(x, y, BLOCK_SIZE, BLOCK_SIZE, true);
                    }
                }
            }
        }
        // 边框
        g.setColor(Color.GRAY);
        for (int i = 0; i <= COLS; i++)
            g.drawLine(i * BLOCK_SIZE, 0, i * BLOCK_SIZE, ROWS * BLOCK_SIZE);
        for (int i = 0; i <= ROWS; i++)
            g.drawLine(0, i * BLOCK_SIZE, COLS * BLOCK_SIZE, i * BLOCK_SIZE);
        // 绘制分数
        g.setColor(Color.DARK_GRAY);
        g.setFont(new Font("微软雅黑", Font.BOLD, 16));
        g.drawString("分数: " + score, 10, 25);

        // 如果正在倒计时，绘制倒计时遮罩
        if (countdownTimer != null && countdownTimer.isRunning()) {
            drawCountdownOverlay(g);
        }

        // 暂停遮罩
        if (paused) {
            g.setColor(new Color(0,0,0,120));
            g.fillRect(0,0,getWidth(),getHeight());
            g.setColor(Color.WHITE);
            g.setFont(new Font("微软雅黑", Font.BOLD, 36));
            g.drawString("已暂停", getWidth()/2-60, getHeight()/2);
        }
    }

    /**
     * 绘制倒计时遮罩和数字。
     * @param g 绘图上下文
     */
    private void drawCountdownOverlay(Graphics g) {
        g.setColor(new Color(0, 0, 0, 100)); // 半透明黑色遮罩
        g.fillRect(0, 0, getWidth(), getHeight());

        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial", Font.BOLD, 80));
        FontMetrics fm = g.getFontMetrics();
        String text = String.valueOf(countdownValue);
        g.drawString(text, (getWidth() - fm.stringWidth(text)) / 2, getHeight() / 2 + fm.getAscent() / 2);
    }

    /**
     * 绘制欢迎界面。
     * @param g 绘图上下文
     */
    private void drawWelcomeScreen(Graphics g) {
        g.setColor(new Color(70, 130, 180)); // 钢蓝色背景
        g.fillRect(0, 0, getWidth(), getHeight());

        g.setColor(Color.WHITE);
        g.setFont(new Font("微软雅黑", Font.BOLD, 36));
        FontMetrics fm = g.getFontMetrics();
        String title = "俄罗斯方块";
        g.drawString(title, (getWidth() - fm.stringWidth(title)) / 2, getHeight() / 2 - 50);

        g.setFont(new Font("微软雅黑", Font.PLAIN, 18));
        fm = g.getFontMetrics();
        String message = "从“游戏”菜单选择“新游戏”开始";
        g.drawString(message, (getWidth() - fm.stringWidth(message)) / 2, getHeight() / 2 + 20);
    }

    /**
     * 响应键盘按键事件，处理玩家操作。
     * @param e 键盘事件对象
     */
    @Override
    public void keyPressed(KeyEvent e) {
        if (!running || paused) return;
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) {
            if (canMove(curRow, curCol - 1, currentBlock.shape)) curCol--;
        } else if (code == KeyEvent.VK_RIGHT) {
            if (canMove(curRow, curCol + 1, currentBlock.shape)) curCol++;
        } else if (code == KeyEvent.VK_DOWN) {
            if (canMove(curRow + 1, curCol, currentBlock.shape)) curRow++;
        } else if (code == KeyEvent.VK_UP) {
            int[][] rotated = currentBlock.rotate();
            if (canMove(curRow, curCol, rotated)) currentBlock.shape = rotated;
        } else if (code == KeyEvent.VK_SPACE) {
            while (canMove(curRow + 1, curCol, currentBlock.shape)) curRow++;
        } else if (code == KeyEvent.VK_P) {
            parent.togglePause();
        }
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}

    /**
     * 设置游戏的暂停状态。
     * @param paused true表示暂停，false表示恢复
     */
    public void setPaused(boolean paused) {
        this.paused = paused;
        repaint();
    }

    /**
     * 获取当前游戏状态，用于序列化（保存游戏）。
     * @return 包含当前游戏数据的 GameData 对象
     */
    public GameData getGameData() {
        return new GameData(board, currentBlock, curRow, curCol, score, running, gameOver);
    }

    /**
     * 从 GameData 对象中加载游戏状态（读取游戏）。
     * @param data 包含游戏数据的对象
     */
    public void loadGameData(GameData data) {
        for (int i = 0; i < ROWS; i++)
            board[i] = Arrays.copyOf(data.board[i], COLS);
        currentBlock = data.currentBlock;
        curRow = data.curRow;
        curCol = data.curCol;
        score = data.score;
        running = data.running;
        gameOver = data.gameOver;
        if (timer != null) timer.stop();
        if (running) {
            timer = new javax.swing.Timer(speed, this);
            timer.start();
        }
        repaint();
    }
}